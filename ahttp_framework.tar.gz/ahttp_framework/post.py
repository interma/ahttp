import requests
import json

url="http://cq01-apptest-cms02.vm.baidu.com:8312/static/http_get_example.php"
r = requests.get(url)
print r.text

#payload={"pass":"","func":"xxx"}
#url="http://cq01-apptest-cms02.vm.baidu.com:8312/static/api/sms.php"
payload={"pass":"a0f7f7b1669995","func":"videoattr_data_in","msg":"interma test"}
url="http://imis.baidu.com:8888/static/api/sms.php"
r = requests.post(url,data=payload)
print r.text
